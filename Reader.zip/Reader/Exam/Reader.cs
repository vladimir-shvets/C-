﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Exam
{
        class OpenFB2
        {
            XmlDocument FB2;
            private char[] buff;
            StringBuilder d = new StringBuilder();
            int c = -1;
            //private int count = 0;
            public OpenFB2()
            {
                FB2 = new XmlDocument();
                buff = new char[2000];
            }
            public int OpenFile(string nameFile)
            {
                Program Pro = new Program();
                FB2.Load(nameFile);//путь к файлу nameFile
                XmlNodeList read = FB2.GetElementsByTagName("body");
                foreach (XmlNode elem in read)
                {
                    string d = elem.InnerText;
                }
                int i = 0, j = 0;
                foreach (XmlNode elem in read)
                {
                    d.Clear();
                    d.Append(elem.InnerText);
                    j = 0;
                    for (; j < d.Length; ++i, ++j)
                    { 
                        buff[i] = d[j];
                        //if (buff[i] == ' ')
                        //{
                        //    buff[i] = '\n';
                        //}
                        if (i == 1999)
                        {
                            Show(buff);
                            Console.WriteLine();
                            c=Pro.Submenu();
                            if(c==0)
                            {
                                return 0;
                            }
                            Console.Clear();
                            i = -1;
                        }
                    }
                }
                return 0;
            }
            public void Show(char[] text)
            {
                for (int i = 0; i < text.Length; ++i)
                {
                    Console.Write(text[i]);
                    
                }
            }
        }
    }

