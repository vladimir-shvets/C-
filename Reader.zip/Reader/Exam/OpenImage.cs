﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Exam
{
    class OpenImage
    {
        public void OpenWithArguments(int i, string path)
        {
                Base64ToImage(XMLImage(i, path));
                // url's are not considered documents. They can only be opened 
                // by passing them as arguments.
                Process.Start("Image.jpg");
        }
        private void Base64ToImage(string base64String)
        {
            // Convert Base64 String to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            using (FileStream fs = new FileStream("Image.jpg", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                BinaryWriter sw = new BinaryWriter(fs, Encoding.UTF8);
                sw.Write(imageBytes);
            }
        }

        private string XMLImage(int i,string path)
        {
            string rez = string.Empty;
            XmlDocument d = new XmlDocument();
            d.Load(path);
            XmlNodeList l = d.GetElementsByTagName("binary");
            int s = l.Count;
            try
            {
            XmlNode f = l[i];
            rez = f.InnerText;
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
            }
             return rez;
        }
    }
}
