﻿using System;
using System.Collections.Generic;
using Cs.FileManager;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Exam;
using System.IO;

namespace Exam
{

    class Program
    {
        static List<string> menu = new List<string> { "Find a file", "Read", "Exit" };
        static List<string> submenu = new List<string> { "1 - Forward", "2 - Back", "3 - Color", "4 - Show image", "5 - Back to menu" };
        static string nameFile = string.Empty;
        static int i = 0;

        static void Menu()
        {
            int origWidth = Console.WindowWidth;
            int origHeight = Console.WindowHeight;

           Console.SetWindowSize(origWidth, origHeight + 10);

            int C = 0;
            do
            {
                C = Choice();
                switch (C)
                {
                    case 0:
                        nameFile = new MenuDirectory().Open();
                        break;
                    case 1:
                        Console.Clear();
                        new OpenFB2().OpenFile(nameFile);
                        break;
                }
            } while (C != 2);
        }
        internal int Submenu()
        {
            foreach (var item in submenu)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(item + " ");
            }
            int V = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Yellow;
            do
            {
                switch (V)
                {
                    case 1:
                        return 1;
                    case 2:
                        break;
                    case 3:

                        break;
                    case 4:
                        new OpenImage().OpenWithArguments(i, nameFile);
                        ++i;
                        return 4;
                }
            } while (V != 5);
            return 0;
        }
        static int Choice()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Blue;

            int current = 0;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("***  MENU  ***");
                int i = 0;
                foreach (var item in menu)
                {

                    if (current == i)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.BackgroundColor = ConsoleColor.Yellow;
                    }

                    Console.WriteLine(item);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.BackgroundColor = ConsoleColor.Blue;

                    ++i;
                }

                ConsoleKeyInfo key = Console.ReadKey();

                #region Keys

                switch (key.Key)
                {
                    case ConsoleKey.A:
                        break;
                    case ConsoleKey.Add:
                        break;
                    case ConsoleKey.Applications:
                        break;
                    case ConsoleKey.Attention:
                        break;
                    case ConsoleKey.B:
                        break;
                    case ConsoleKey.Backspace:
                        break;
                    case ConsoleKey.BrowserBack:
                        break;
                    case ConsoleKey.BrowserFavorites:
                        break;
                    case ConsoleKey.BrowserForward:
                        break;
                    case ConsoleKey.BrowserHome:
                        break;
                    case ConsoleKey.BrowserRefresh:
                        break;
                    case ConsoleKey.BrowserSearch:
                        break;
                    case ConsoleKey.BrowserStop:
                        break;
                    case ConsoleKey.C:
                        break;
                    case ConsoleKey.Clear:
                        break;
                    case ConsoleKey.CrSel:
                        break;
                    case ConsoleKey.D:
                        break;
                    case ConsoleKey.D0:
                        break;
                    case ConsoleKey.D1:
                        break;
                    case ConsoleKey.D2:
                        break;
                    case ConsoleKey.D3:
                        break;
                    case ConsoleKey.D4:
                        break;
                    case ConsoleKey.D5:
                        break;
                    case ConsoleKey.D6:
                        break;
                    case ConsoleKey.D7:
                        break;
                    case ConsoleKey.D8:
                        break;
                    case ConsoleKey.D9:
                        break;
                    case ConsoleKey.Decimal:
                        break;
                    case ConsoleKey.Delete:
                        break;
                    case ConsoleKey.Divide:
                        break;
                    case ConsoleKey.DownArrow: ++current;
                        break;
                    case ConsoleKey.E:
                        break;
                    case ConsoleKey.End:
                        break;
                    case ConsoleKey.Enter: return current;
                        break;
                    case ConsoleKey.EraseEndOfFile:
                        break;
                    case ConsoleKey.Escape:
                        break;
                    case ConsoleKey.ExSel:
                        break;
                    case ConsoleKey.Execute:
                        break;
                    case ConsoleKey.F:
                        break;
                    case ConsoleKey.F1:
                        break;
                    case ConsoleKey.F10:
                        break;
                    case ConsoleKey.F11:
                        break;
                    case ConsoleKey.F12:
                        break;
                    case ConsoleKey.F13:
                        break;
                    case ConsoleKey.F14:
                        break;
                    case ConsoleKey.F15:
                        break;
                    case ConsoleKey.F16:
                        break;
                    case ConsoleKey.F17:
                        break;
                    case ConsoleKey.F18:
                        break;
                    case ConsoleKey.F19:
                        break;
                    case ConsoleKey.F2:
                        break;
                    case ConsoleKey.F20:
                        break;
                    case ConsoleKey.F21:
                        break;
                    case ConsoleKey.F22:
                        break;
                    case ConsoleKey.F23:
                        break;
                    case ConsoleKey.F24:
                        break;
                    case ConsoleKey.F3:
                        break;
                    case ConsoleKey.F4:
                        break;
                    case ConsoleKey.F5:
                        break;
                    case ConsoleKey.F6:
                        break;
                    case ConsoleKey.F7:
                        break;
                    case ConsoleKey.F8:
                        break;
                    case ConsoleKey.F9:
                        break;
                    case ConsoleKey.G:
                        break;
                    case ConsoleKey.H:
                        break;
                    case ConsoleKey.Help:
                        break;
                    case ConsoleKey.Home:
                        break;
                    case ConsoleKey.I:
                        break;
                    case ConsoleKey.Insert:
                        break;
                    case ConsoleKey.J:
                        break;
                    case ConsoleKey.K:
                        break;
                    case ConsoleKey.L:
                        break;
                    case ConsoleKey.LaunchApp1:
                        break;
                    case ConsoleKey.LaunchApp2:
                        break;
                    case ConsoleKey.LaunchMail:
                        break;
                    case ConsoleKey.LaunchMediaSelect:
                        break;
                    case ConsoleKey.LeftArrow:
                        break;
                    case ConsoleKey.LeftWindows:
                        break;
                    case ConsoleKey.M:
                        break;
                    case ConsoleKey.MediaNext:
                        break;
                    case ConsoleKey.MediaPlay:
                        break;
                    case ConsoleKey.MediaPrevious:
                        break;
                    case ConsoleKey.MediaStop:
                        break;
                    case ConsoleKey.Multiply:
                        break;
                    case ConsoleKey.N:
                        break;
                    case ConsoleKey.NoName:
                        break;
                    case ConsoleKey.NumPad0:
                        break;
                    case ConsoleKey.NumPad1:
                        break;
                    case ConsoleKey.NumPad2:
                        break;
                    case ConsoleKey.NumPad3:
                        break;
                    case ConsoleKey.NumPad4:
                        break;
                    case ConsoleKey.NumPad5:
                        break;
                    case ConsoleKey.NumPad6:
                        break;
                    case ConsoleKey.NumPad7:
                        break;
                    case ConsoleKey.NumPad8:
                        break;
                    case ConsoleKey.NumPad9:
                        break;
                    case ConsoleKey.O:
                        break;
                    case ConsoleKey.Oem1:
                        break;
                    case ConsoleKey.Oem102:
                        break;
                    case ConsoleKey.Oem2:
                        break;
                    case ConsoleKey.Oem3:
                        break;
                    case ConsoleKey.Oem4:
                        break;
                    case ConsoleKey.Oem5:
                        break;
                    case ConsoleKey.Oem6:
                        break;
                    case ConsoleKey.Oem7:
                        break;
                    case ConsoleKey.Oem8:
                        break;
                    case ConsoleKey.OemClear:
                        break;
                    case ConsoleKey.OemComma:
                        break;
                    case ConsoleKey.OemMinus:
                        break;
                    case ConsoleKey.OemPeriod:
                        break;
                    case ConsoleKey.OemPlus:
                        break;
                    case ConsoleKey.P:
                        break;
                    case ConsoleKey.Pa1:
                        break;
                    case ConsoleKey.Packet:
                        break;
                    case ConsoleKey.PageDown:
                        break;
                    case ConsoleKey.PageUp:
                        break;
                    case ConsoleKey.Pause:
                        break;
                    case ConsoleKey.Play:
                        break;
                    case ConsoleKey.Print:
                        break;
                    case ConsoleKey.PrintScreen:
                        break;
                    case ConsoleKey.Process:
                        break;
                    case ConsoleKey.Q:
                        break;
                    case ConsoleKey.R:
                        break;
                    case ConsoleKey.RightArrow:
                        break;
                    case ConsoleKey.RightWindows:
                        break;
                    case ConsoleKey.S:
                        break;
                    case ConsoleKey.Select:
                        break;
                    case ConsoleKey.Separator:
                        break;
                    case ConsoleKey.Sleep:
                        break;
                    case ConsoleKey.Spacebar:
                        break;
                    case ConsoleKey.Subtract:
                        break;
                    case ConsoleKey.T:
                        break;
                    case ConsoleKey.Tab:
                        break;
                    case ConsoleKey.U:
                        break;
                    case ConsoleKey.UpArrow: --current;
                        break;
                    case ConsoleKey.V:
                        break;
                    case ConsoleKey.VolumeDown:
                        break;
                    case ConsoleKey.VolumeMute:
                        break;
                    case ConsoleKey.VolumeUp:
                        break;
                    case ConsoleKey.W:
                        break;
                    case ConsoleKey.X:
                        break;
                    case ConsoleKey.Y:
                        break;
                    case ConsoleKey.Z:
                        break;
                    case ConsoleKey.Zoom:
                        break;
                    default:
                        break;
                }

                #endregion
            }
            return 0;
        }

        #region Color
        public object Cyan
        {
            get
            {
                return Console.ForegroundColor = ConsoleColor.Cyan;
            }
        }
        #endregion
        static void Main(string[] args)
        {
            Program.Menu();

        }
    }
}
