﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.IO.Compression;
using Exam;

namespace Cs.FileManager
{
    class MenuDirectory
    {
        private int _indexLevel = 0;
        private string _path = string.Empty;
        private List<string> _pathback = new List<string>();
        private int _indpathback = -1;
        private StringBuilder check1 = new StringBuilder(".zip");
        private StringBuilder check2 = new StringBuilder(".fb2");
        private StringBuilder check3 = new StringBuilder();
        private int result = 0;
        public MenuDirectory()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Blue;

        }
        private void OpenZip(string zipPath)
        {
            //string zipPath = @"D:\Soldaty_Armageddona.zip";//получить имя пути архива
                string extractPath = Path.GetFullPath("Debug");//получить имя пути Debug
                string d = "\\Debug";
                int s = d.Length;
                for (int i = extractPath.Length; s > 0; --i, --s)
                {
                    extractPath = extractPath.Remove(i - 1);
                }
                StringBuilder dfg = new StringBuilder(extractPath);
                dfg.Append("\\book");
                ZipFile.ExtractToDirectory(zipPath, dfg.ToString());//добавить папку book и сохранить файл
        }

        public string Open()
        {
            while (true)
            {
                result = 0;

                IEnumerable<string> items = null;

                if (_indexLevel == 0)
                {
                    items = Directory.GetLogicalDrives().ToList();
                    (items as List<string>).Insert(0, "<--Назад");
                }
                else
                {
                    items = Directory.GetFileSystemEntries(_path).ToList();
                    (items as List<string>).Insert(0, "..");
                }

                result = ShowEntries(items);

                if (result == 0 && _indpathback == -1)
                {
                    return null;
                }
                else if (Rollback())
                {
                    //Back
                }
                else
                {
                    _path = Path.GetFullPath(string.Format("{0}", (items as List<string>)[result]));
                    check3.Append(Path.GetExtension(_path));
                    if (check1.Equals(check3) == true)
                    {
                        OpenZip(_path);
                        check3.Clear();
                        _path = _pathback[_indpathback];
                    }
                    else if (check2.Equals(check3) == true)
                    {
                        return _path;
                        check3.Clear();
                    }
                    else
                    {
                        _pathback.Add(_path);
                        ++_indpathback;
                        ++_indexLevel;
                    }

                }

            }
        }

        private int ShowEntries(IEnumerable<string> items)
        {
            int current = 0;

            while (true)
            {
                Console.Clear();

                int i = 0;
                foreach (var item in items)
                {

                    if (current == i)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.BackgroundColor = ConsoleColor.Yellow;
                    }

                    Console.WriteLine(item);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.BackgroundColor = ConsoleColor.Blue;

                    ++i;
                }

                ConsoleKeyInfo key = Console.ReadKey();

                #region Keys

                switch (key.Key)
                {
                    case ConsoleKey.A:
                        break;
                    case ConsoleKey.Add:
                        break;
                    case ConsoleKey.Applications:
                        break;
                    case ConsoleKey.Attention:
                        break;
                    case ConsoleKey.B:
                        break;
                    case ConsoleKey.Backspace:
                        break;
                    case ConsoleKey.BrowserBack:
                        break;
                    case ConsoleKey.BrowserFavorites:
                        break;
                    case ConsoleKey.BrowserForward:
                        break;
                    case ConsoleKey.BrowserHome:
                        break;
                    case ConsoleKey.BrowserRefresh:
                        break;
                    case ConsoleKey.BrowserSearch:
                        break;
                    case ConsoleKey.BrowserStop:
                        break;
                    case ConsoleKey.C:
                        break;
                    case ConsoleKey.Clear:
                        break;
                    case ConsoleKey.CrSel:
                        break;
                    case ConsoleKey.D:
                        break;
                    case ConsoleKey.D0:
                        break;
                    case ConsoleKey.D1:
                        break;
                    case ConsoleKey.D2:
                        break;
                    case ConsoleKey.D3:
                        break;
                    case ConsoleKey.D4:
                        break;
                    case ConsoleKey.D5:
                        break;
                    case ConsoleKey.D6:
                        break;
                    case ConsoleKey.D7:
                        break;
                    case ConsoleKey.D8:
                        break;
                    case ConsoleKey.D9:
                        break;
                    case ConsoleKey.Decimal:
                        break;
                    case ConsoleKey.Delete:
                        break;
                    case ConsoleKey.Divide:
                        break;
                    case ConsoleKey.DownArrow: ++current;
                        break;
                    case ConsoleKey.E:
                        break;
                    case ConsoleKey.End:
                        break;
                    case ConsoleKey.Enter: return current;
                        break;
                    case ConsoleKey.EraseEndOfFile:
                        break;
                    case ConsoleKey.Escape:
                        break;
                    case ConsoleKey.ExSel:
                        break;
                    case ConsoleKey.Execute:
                        break;
                    case ConsoleKey.F:
                        break;
                    case ConsoleKey.F1:
                        break;
                    case ConsoleKey.F10:
                        break;
                    case ConsoleKey.F11:
                        break;
                    case ConsoleKey.F12:
                        break;
                    case ConsoleKey.F13:
                        break;
                    case ConsoleKey.F14:
                        break;
                    case ConsoleKey.F15:
                        break;
                    case ConsoleKey.F16:
                        break;
                    case ConsoleKey.F17:
                        break;
                    case ConsoleKey.F18:
                        break;
                    case ConsoleKey.F19:
                        break;
                    case ConsoleKey.F2:
                        break;
                    case ConsoleKey.F20:
                        break;
                    case ConsoleKey.F21:
                        break;
                    case ConsoleKey.F22:
                        break;
                    case ConsoleKey.F23:
                        break;
                    case ConsoleKey.F24:
                        break;
                    case ConsoleKey.F3:
                        break;
                    case ConsoleKey.F4:
                        break;
                    case ConsoleKey.F5:
                        break;
                    case ConsoleKey.F6:
                        break;
                    case ConsoleKey.F7:
                        break;
                    case ConsoleKey.F8:
                        break;
                    case ConsoleKey.F9:
                        break;
                    case ConsoleKey.G:
                        break;
                    case ConsoleKey.H:
                        break;
                    case ConsoleKey.Help:
                        break;
                    case ConsoleKey.Home:
                        break;
                    case ConsoleKey.I:
                        break;
                    case ConsoleKey.Insert:
                        break;
                    case ConsoleKey.J:
                        break;
                    case ConsoleKey.K:
                        break;
                    case ConsoleKey.L:
                        break;
                    case ConsoleKey.LaunchApp1:
                        break;
                    case ConsoleKey.LaunchApp2:
                        break;
                    case ConsoleKey.LaunchMail:
                        break;
                    case ConsoleKey.LaunchMediaSelect:
                        break;
                    case ConsoleKey.LeftArrow:
                        break;
                    case ConsoleKey.LeftWindows:
                        break;
                    case ConsoleKey.M:
                        break;
                    case ConsoleKey.MediaNext:
                        break;
                    case ConsoleKey.MediaPlay:
                        break;
                    case ConsoleKey.MediaPrevious:
                        break;
                    case ConsoleKey.MediaStop:
                        break;
                    case ConsoleKey.Multiply:
                        break;
                    case ConsoleKey.N:
                        break;
                    case ConsoleKey.NoName:
                        break;
                    case ConsoleKey.NumPad0:
                        break;
                    case ConsoleKey.NumPad1:
                        break;
                    case ConsoleKey.NumPad2:
                        break;
                    case ConsoleKey.NumPad3:
                        break;
                    case ConsoleKey.NumPad4:
                        break;
                    case ConsoleKey.NumPad5:
                        break;
                    case ConsoleKey.NumPad6:
                        break;
                    case ConsoleKey.NumPad7:
                        break;
                    case ConsoleKey.NumPad8:
                        break;
                    case ConsoleKey.NumPad9:
                        break;
                    case ConsoleKey.O:
                        break;
                    case ConsoleKey.Oem1:
                        break;
                    case ConsoleKey.Oem102:
                        break;
                    case ConsoleKey.Oem2:
                        break;
                    case ConsoleKey.Oem3:
                        break;
                    case ConsoleKey.Oem4:
                        break;
                    case ConsoleKey.Oem5:
                        break;
                    case ConsoleKey.Oem6:
                        break;
                    case ConsoleKey.Oem7:
                        break;
                    case ConsoleKey.Oem8:
                        break;
                    case ConsoleKey.OemClear:
                        break;
                    case ConsoleKey.OemComma:
                        break;
                    case ConsoleKey.OemMinus:
                        break;
                    case ConsoleKey.OemPeriod:
                        break;
                    case ConsoleKey.OemPlus:
                        break;
                    case ConsoleKey.P:
                        break;
                    case ConsoleKey.Pa1:
                        break;
                    case ConsoleKey.Packet:
                        break;
                    case ConsoleKey.PageDown:
                        break;
                    case ConsoleKey.PageUp:
                        break;
                    case ConsoleKey.Pause:
                        break;
                    case ConsoleKey.Play:
                        break;
                    case ConsoleKey.Print:
                        break;
                    case ConsoleKey.PrintScreen:
                        break;
                    case ConsoleKey.Process:
                        break;
                    case ConsoleKey.Q:
                        break;
                    case ConsoleKey.R:
                        break;
                    case ConsoleKey.RightArrow:
                        break;
                    case ConsoleKey.RightWindows:
                        break;
                    case ConsoleKey.S:
                        break;
                    case ConsoleKey.Select:
                        break;
                    case ConsoleKey.Separator:
                        break;
                    case ConsoleKey.Sleep:
                        break;
                    case ConsoleKey.Spacebar:
                        break;
                    case ConsoleKey.Subtract:
                        break;
                    case ConsoleKey.T:
                        break;
                    case ConsoleKey.Tab:
                        break;
                    case ConsoleKey.U:
                        break;
                    case ConsoleKey.UpArrow: --current;
                        break;
                    case ConsoleKey.V:
                        break;
                    case ConsoleKey.VolumeDown:
                        break;
                    case ConsoleKey.VolumeMute:
                        break;
                    case ConsoleKey.VolumeUp:
                        break;
                    case ConsoleKey.W:
                        break;
                    case ConsoleKey.X:
                        break;
                    case ConsoleKey.Y:
                        break;
                    case ConsoleKey.Z:
                        break;
                    case ConsoleKey.Zoom:
                        break;
                    default:
                        break;
                }

                #endregion
            }

            return 0;
        }

        private bool Rollback()
        {
            if (result == 0 && _indpathback == 0)
            {
                _pathback.Clear();
                _indpathback = -1;
                --_indexLevel;
                return true;
            }
            else if (result == 0)
            {
                _path = _pathback[_indpathback - 1];
                _pathback.RemoveAt(_indpathback);
                --_indpathback;
                --_indexLevel;
                return true;
            }

            return false;
        }
    }
}
