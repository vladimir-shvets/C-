﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Util.Store;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoogleDocs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public Google.Apis.Services.BaseClientService.Initializer Auth()
        {
            string[] scopes = new string[] { DriveService.Scope.Drive,
                                 DriveService.Scope.DriveFile};
            var clientId = "149788749507-q0jr94sm87n93otdbuftpf8prlqgofju.apps.googleusercontent.com";   
            var clientSecret = "v0s6A23NNQCLQFoD3xCY8S0Q";          

            try
            {
                var credential = GoogleWebAuthorizationBroker.AuthorizeAsync(new ClientSecrets
                {
                    ClientId = clientId,
                    ClientSecret = clientSecret
                }, scopes, Environment.UserName, CancellationToken.None, new FileDataStore("Daimto.GoogleDrive.Auth.Store")).Result;

                BaseClientService.Initializer initializer = new BaseClientService.Initializer
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                };
                return initializer;
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);
                return null;
            }
        }
        public static List<Google.Apis.Drive.v3.Data.File> retrieveTableFiles(DriveService service)
        {
            List<Google.Apis.Drive.v3.Data.File> File = new List<Google.Apis.Drive.v3.Data.File>();

            try
            {
                FilesResource.ListRequest list = service.Files.List();
                list.Q = "mimeType='application/vnd.google-apps.spreadsheet'";
                FileList filesFeed = list.Execute();
                while (filesFeed.Files != null)
                {
                    foreach (var item in filesFeed.Files)
                    {
                      
                        File.Add(item);
                    }
                    if (filesFeed.NextPageToken == null)
                    {
                        break;
                    }
                    list.PageToken = filesFeed.NextPageToken;
                    filesFeed = list.Execute();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return File;
        }

        public List<Google.Apis.Drive.v3.Data.File> GetListFiles(object sender)
        {
            listBox1.DisplayMember = "Name";
            List<Google.Apis.Drive.v3.Data.File> list = retrieveTableFiles(new DriveService(Auth()));
            for (int i = 0; i < list.Count; i++)
            {
                ((ListBox)sender).Items.Add(list[i]);
            }
            return list;
        }

        private void dgv_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].HeaderCell.Value =
                (e.RowIndex + 1).ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Enabled = false;
            dataGridView1.MultiSelect = false;
            dataGridView1.Rows.Clear();
            try
            {
                var Sheetid = ((Google.Apis.Drive.v3.Data.File)listBox1.SelectedItem).Id;
                var service = new SheetsService(Auth());
                string range = "A1:Z1000";
                SpreadsheetsResource.ValuesResource.GetRequest request =
                        service.Spreadsheets.Values.Get(Sheetid, range);
                ValueRange response = request.Execute();
                IList<IList<Object>> values = response.Values;
                if (values != null && values.Count > 0)
                {
                    dataGridView1.ColumnCount = 26;
                    dataGridView1.ColumnHeadersVisible = true;
                    dataGridView1.RowHeadersVisible = true;
                    for (int i = 0; i < 26; i++)
                    {
                        char ch = Convert.ToChar(65 + i);
                        dataGridView1.Columns[i].Name = ch.ToString();
                        dataGridView1.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    foreach (var row in values)
                    {
                        string[] str = new string[row.Count];
                        for (int i = 0; i < row.Count; i++)
                        {
                            str[i] = row[i].ToString();

                        }

                        dataGridView1.Rows.Add(str);
                    }
                    button2.Visible = true;
                }
                else
                {
                    button2.Visible = false;
                }
            }
            catch (Exception a)
            {
                MessageBox.Show(a.Message);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            GetListFiles(listBox1);
            button1.Enabled = false;
            button2.Visible = false;
            panel1.Visible = false;
        }
        CookieContainer cookie = new CookieContainer();
        public bool HttprequestAuth(string uri, string log, string pas)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            
            request.CookieContainer = cookie;
            request.Method = "POST";
            string postData = "login=" + log + "&password=" + pas + "&go=login&action=login&save_session=1";
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            dataStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);
            string responseFromServer = reader.ReadToEnd();
            if (responseFromServer.IndexOf("Логин и пароль для входа ошибочные") == -1)
            {
                MessageBox.Show("Вы вошли");
                return true;
            }
            else
            {
                MessageBox.Show("Логин и пароль для входа ошибочные");
                textBox1.Clear();
                textBox2.Clear();
                return false;
            }
        }
        public string Search(string search)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://mediateka.com.ua/?search_cl="+search);
            request.Method = "GET";
            request.CookieContainer = cookie;
            HttpWebResponse resp = (HttpWebResponse)request.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string Out = sr.ReadToEnd();
            string res = "Результат: найдено записей ";
            string result = Out.Substring(Out.IndexOf(res) + res.Length, Out.IndexOf(',', (Out.IndexOf(res) + res.Length)) - (Out.IndexOf(res) + res.Length));
            sr.Close();
            return result;
        }
        string resultat;
        List<object> listrez = new List<object>();

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Enabled = false;
            resultat = "";
            try
            {
                var v = dataGridView1.SelectedCells;
                int col = v[0].ColumnIndex;
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    var val = dataGridView1.Rows[i].Cells[col].Value;
                    if (val != null)
                    {
                        string[] rez = ((string)val).Split(new char[] { ' ' });
                        foreach (var vr in rez)
                        {
                            if (rez[0] == "") break;
                            resultat += vr;
                            resultat += "+";
                        }
                        if (resultat.Length == 0) break;
                        resultat.Substring(0, resultat.Length - 1);
                        string date_from = dateTimePicker1.Value.Year.ToString() + "-" + dateTimePicker1.Value.Month.ToString() + "-" + dateTimePicker1.Value.Day.ToString();
                        string date_to = dateTimePicker2.Value.Year.ToString() + "-" + dateTimePicker2.Value.Month.ToString() + "-" + dateTimePicker2.Value.Day.ToString();
                        resultat += "&";
                        resultat += "date_from=" + date_from;
                        resultat += "&";
                        resultat += "date_to=" + dateTimePicker2.Value.ToShortDateString();
                        resultat += "&data_zag=1";
                    }
                    if (resultat.Length != 0)
                    {
                        listrez.Add(Search(resultat));
                        UpdateSheets(listrez, i);
                        resultat = "";
                    }
                    else
                    {
                        listrez.Add("");
                        UpdateSheets(listrez, i);
                    }
                }
            }
            catch(Exception a)
            {
                MessageBox.Show(a.Message);
            }
            dataGridView1.Enabled = true;
        }
        public void UpdateSheets(IList<object> r, int row)
        {
            IList<IList<object>> l = new List<IList<object>>();
            var Sheetid = ((Google.Apis.Drive.v3.Data.File)listBox1.SelectedItem).Id;
            for (int i = 0; i < r.Count; i++)
            {
                    l.Add(new List<object>());
                    l[i].Add(r[i]);
            }
            var service = new SheetsService(Auth());
            var v = dataGridView1.SelectedCells;
            ValueRange a = new ValueRange();
            a.MajorDimension = "ROWS";
            int ch = (v[0].ColumnIndex + 1);
            string range = dataGridView1.Columns[ch].Name + "1:" + dataGridView1.Columns[ch].Name + dataGridView1.RowCount.ToString();
            a.Values = l;
            SpreadsheetsResource.ValuesResource.UpdateRequest request =
          service.Spreadsheets.Values.Update(a, Sheetid, range);
            request.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.RAW;
            UpdateValuesResponse result2 = request.Execute();
        }
        private void button3_Click(object sender, EventArgs e)
        {

            if (HttprequestAuth("http://mediateka.com.ua/", textBox1.Text, textBox2.Text))
            {
                panel1.Visible = true;
                button1.Enabled = true;
            }
        }
    }
}
