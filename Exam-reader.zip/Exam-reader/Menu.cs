﻿using System;

namespace ExamReader
{
	public class Menu
	{
		public Menu ()
		{
		}
	}
}

