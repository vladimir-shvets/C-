﻿//using UnityEngine;
using System;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;

namespace ExamReader
{
	class Program
	{
		static void Main(string[] args)
		{
			OpenFB2 doc = new OpenFB2 ();
			bool fl = true;
			do
			{
				Console.WriteLine("*********** Menu ***********");
                Console.WriteLine("Create file for write -> 1\nOpen created file for reading -> 2\nDelete file->3\nChange font color->4\nChange background color->5\nOpen FB2 file->6\nExit -> 7");
                Console.WriteLine("****************************************");

				switch (Int16.Parse(Console.ReadLine()))
				{
				case 1: 
					doc.CreateFile();
					break;
				case 2: 
					doc.OpenFile();
					break;
				case 3:
					doc.DelFile();
					break;
				case 4:
					doc.Foreground();
					break;
				case 5: 
					doc.Background();
					break;
				case 6:
					doc.OpenFile();
					break;
				case 7: 
					fl = false;
					Console.WriteLine("Good-Bye!");
					break;

				default:
					Console.WriteLine("Incorrect input!");
					break;
				}
			} while (fl);
		}


	}

}