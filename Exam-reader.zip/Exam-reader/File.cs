﻿using System;
using System.Xml;
using System.Text;
using System.IO;


using System.Collections;

using System.Text.RegularExpressions;

namespace ExamReader
{
	class OpenFB2
	{
		XmlDocument FB2;
		private char[] buff;
		StringBuilder d = new StringBuilder();
		int c = -1;
		//private int count = 0;
		public OpenFB2()
		{
			FB2 = new XmlDocument();
			buff = new char[2000];
		}
		public int OpenFile(string nameFile)
		{
			Program Pro = new Program();
			FB2.Load(nameFile);//путь к файлу nameFile
			XmlNodeList read = FB2.GetElementsByTagName("body");
			foreach (XmlNode elem in read)
			{
				string d = elem.InnerText;
			}
			int i = 0, j = 0;
			foreach (XmlNode elem in read)
			{
				d.Clear();
				d.Append(elem.InnerText);
				j = 0;
				for (; j < d.Length; ++i, ++j)
				{ 
					buff[i] = d[j];
					//if (buff[i] == ' ')
					//{
					//    buff[i] = '\n';
					//}
					if (i == 1999)
					{
						Show(buff);
						Console.WriteLine();
						//c=Pro.Submenu();
						if(c==0)
						{
							return 0;
						}
						Console.Clear();
						i = -1;
					}
				}
			}
			return 0;
		}
		public void Show(char[] text)
		{
			for (int i = 0; i < text.Length; ++i)
			{
				Console.Write(text[i]);

			}
		}



		public void CreateFile()
		{
			try
			{
				Console.Write("Name of creating file: ");
				FileStream fs = new FileStream(Console.ReadLine() + ".txt", FileMode.Create);
				Console.WriteLine("ТЕКСТ СООБЩЕНИЯ: ");
				string text = Console.ReadLine();
				StreamWriter s = new StreamWriter(fs);
				s.WriteLine(text);
				s.Close();
			}
			catch (Exception ex)
			{ Console.WriteLine("Error: {0}\n", ex.Message); }

		}
		public void OpenFile()
		{
			try
			{
				Console.WriteLine("Please enter name of file you want to open and its extension: ");
				using (StreamReader sr = new StreamReader(Console.ReadLine()))
				{
					string line; 
					Console.WriteLine("ТЕКСТ ИЗ ФАЙЛА: \n");
					while ((line = sr.ReadLine()) != null)
					{ Console.WriteLine(line); }
				}
			}
			catch (Exception ex)
			{ 
				Console.WriteLine ("No such file!Please check the file path!");
				Console.WriteLine("Path: {0}\n", ex.Message); }

		}
		public void DelFile()
		{
			Console.WriteLine("Please enter name of file you want to delete: ");
			string path = Console.ReadLine () + ".txt";
			File.Delete(path);
			Console.WriteLine ("File have succesfully deleted!\n");

		}


		public void Foreground()
		{
			Console.WriteLine ("Please choose colour one of listed for Font:\n 1.Green\n 2.Blue\n 3.Yellow\n 4.Black\n 5.Dark Blue\n 6.White\n");
			char ch = Convert.ToChar (Console.ReadLine ());
			//int down = Convert.ToInt32 (Console.ReadLine ());
			switch (ch) {
			case '1':
				Console.ForegroundColor = ConsoleColor.Green;
				break;

			case '2':
				Console.ForegroundColor = ConsoleColor.Blue;
				break;

			case '3':
				Console.ForegroundColor = ConsoleColor.Yellow;
				break;

			case '4':
				Console.ForegroundColor = ConsoleColor.Black;
				break;

			case '5':
				Console.ForegroundColor = ConsoleColor.DarkBlue;
				break;

			case '6':
				Console.ForegroundColor = ConsoleColor.White;
				break;

			default:
				Console.WriteLine ("Error!Please choose the color from the list above!\n");
				break;

			}
			Console.Clear ();
		}

		public void Background()
		{
			Console.WriteLine ("Please choose colour one of listed for your Background:\n 1.Green\n 2.Blue\n 3.Yellow\n 4.Black\n 5.Dark Blue\n 6.White\n");
			char ch = Convert.ToChar (Console.ReadLine ());
			//int down = Convert.ToInt32 (Console.ReadLine ());
			switch (ch) {
			case '1':
				Console.BackgroundColor = ConsoleColor.Green;
				break;

			case '2':
				Console.BackgroundColor = ConsoleColor.Blue;
				break;

			case '3':
				Console.BackgroundColor = ConsoleColor.Yellow;
				break;

			case '4':
				Console.BackgroundColor = ConsoleColor.Black;
				break;

			case '5':
				Console.BackgroundColor = ConsoleColor.DarkBlue;
				break;

			case '6':
				Console.BackgroundColor = ConsoleColor.White;
				break;

			default:
				Console.WriteLine ("Error!Please choose the color from the list above!\n");
				break;

			}
			Console.Clear ();
		}


	}
}

